package com.univ.task_1_2;

public class Task_1_2_Class {
    public String str;

    public Task_1_2_Class(String str) {
        this.str = str;
    }

    protected void method_1(){
        System.out.println("Hello");
    }

    public void method_2(){
        System.out.println("Hello");
    }
}
