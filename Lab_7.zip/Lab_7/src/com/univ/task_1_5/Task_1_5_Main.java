package com.univ.task_1_5;

public class Task_1_5_Main {
    public static void Task_1_5_Main_Run(String[] args)
    {
        Task_1_5_Debug.printDebug("Init class 1");
        Task_1_5_DebugOff.printDebug("Init class 2");
    }
}
