package com.univ.task_1_3_and_1_4;

import com.univ.task_1_2.Task_1_2_Class;

public class Task_1_3_and_1_4_Main {
    public static void Task_1_3_and_1_4_Main_Run(){
        Task_1_3_and_1_4_Class temp = new Task_1_3_and_1_4_Class("Hello", "Jim", "Beam");
        System.out.println(temp.str1);
        System.out.println(temp.str2);
        //А ось тут вже не можна, буде помилка
        //System.out.println(temp.str3);
    }
}
