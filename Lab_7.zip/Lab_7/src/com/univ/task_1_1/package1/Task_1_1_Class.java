package com.univ.task_1_1.package1;

public class Task_1_1_Class {
    public String str;

    public Task_1_1_Class(String str) {
        this.str = str;
    }
}
