package com.univ.task_1_1.package2;

import com.univ.task_1_1.package1.Task_1_1_Class;

public class Task_1_1_Main {
    public static void Task_1_1_Main_Run()
    {
        Task_1_1_Class temp = new Task_1_1_Class("Hello");
    }
}
