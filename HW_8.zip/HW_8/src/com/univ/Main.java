package com.univ;

import com.univ.Task_3_8.Task_3_8_main;
import com.univ.Task_4_15.Task_4_15_main;

public class Main {

    public static void main(String[] args) {
        //Task_3_8_main.main();
        Task_4_15_main.main();
    }
}
