package com.univ;

import com.univ.Task_3_1.Task_3_1_Main;
import com.univ.Task_4_0.Task_4_0_Main;
import com.univ.Task_4_1.Task_4_1_Main;

public class Main {

    public static void main(String[] args) {
        //Task_3_1_Main.main();
        Task_4_0_Main.main();
        //Task_4_1_Main.main();
    }
}
